﻿//clase para acessar banco
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Gestor
{
    class DALCliente
    {
        private Conexao objConexao;

        public DALCliente(Conexao conexao)
        {
            objConexao = conexao;

        }
        //metodo incluir
        public void Incluir(Cliente cliente)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = objConexao.ObjetoConexao;
            cmd.CommandText = "insert into sistema.dbo.clientes (CLIENTE_NOME,CLIENTE_EMAIL,CLIENTE_CEL," +
                                                      "CLIENTE_RUA,CLIENTE_BAIRRO,CLIENTE_CIDADE," +
                                                      "CLIENTE_CEP,CLIENTE_TAXA)" +
                                                      "VALUES (@nome, @email, @cel, @rua, @bairro, @cidade, @cep, @taxa ); select @@IDENTITY;";
            cmd.Parameters.AddWithValue("@nome", cliente.Nome);
            cmd.Parameters.AddWithValue("@email", cliente.Email);
            cmd.Parameters.AddWithValue("@cel", cliente.Cel);
            cmd.Parameters.AddWithValue("@rua", cliente.Rua);
            cmd.Parameters.AddWithValue("@bairro", cliente.Bairro);
            cmd.Parameters.AddWithValue("@cidade", cliente.Cidade);
            cmd.Parameters.AddWithValue("@cep", cliente.Cep);
            cmd.Parameters.AddWithValue("@taxa", cliente.Taxa);
            objConexao.Conectar();
            cliente.Codigo = Convert.ToInt32(cmd.ExecuteScalar());
            objConexao.Desconectar();
        }
        public void Alterar(Cliente cliente)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = objConexao.ObjetoConexao;
            cmd.CommandText = "update sistema.dbo.clientes set CLIENTE_NOME=@nome,CLIENTE_EMAIL=@email," +
                                                      "CLIENTE_CEL=@cel,CLIENTE_RUA=@rua," +
                                                      "CLIENTE_BAIRRO=@bairro,CLIENTE_CIDADE=@cidade," +
                                                      "CLIENTE_CEP=@cep,CLIENTE_TAXA=@taxa" +
                                                      "where CLIENTE_COD=@cod";
            cmd.Parameters.AddWithValue("@cod", cliente.Codigo);
            cmd.Parameters.AddWithValue("@nome", cliente.Nome);
            cmd.Parameters.AddWithValue("@email", cliente.Email);
            cmd.Parameters.AddWithValue("@cel", cliente.Cel);
            cmd.Parameters.AddWithValue("@rua", cliente.Rua);
            cmd.Parameters.AddWithValue("@bairro", cliente.Bairro);
            cmd.Parameters.AddWithValue("@cidade", cliente.Cidade);
            cmd.Parameters.AddWithValue("@cep", cliente.Cep);
            cmd.Parameters.AddWithValue("@taxa", cliente.Taxa);
            objConexao.Conectar();
            cmd.ExecuteNonQuery();
            objConexao.Desconectar();
        }
        public void Excluir(int codigo)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = objConexao.ObjetoConexao;
            cmd.CommandText = "delete from sistema.dbo.clientes where CLIENTE_COD=@cod";
            cmd.Parameters.AddWithValue("@cod",codigo );
            objConexao.Conectar();
            cmd.ExecuteNonQuery();
            objConexao.Desconectar();
        }
    }
}
