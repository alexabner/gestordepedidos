﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestor
{
    public class Cliente
    {
        //criando construtor para a classe Cliente
        public Cliente(){
            this.Codigo = 0;
            this.Nome = "";
            this.Email = "";
            this.Cel = "";
            this.Rua = "";
            this.Bairro = "";
            this.Cidade = "";
            this.Cep = "";
            this.Taxa = "";
        }
        //criando um contrutor para receber todos os dados do cliente
        public Cliente(int codigo,string nome, string email, 
            string cel, string rua, string bairro, 
            string cidade, string estado, string cep, string taxa)
        {
            this.Codigo = codigo;
            this.Nome = nome;
            this.Email = email;
            this.Cel = cel;
            this.Rua = rua;
            this.Bairro = bairro;
            this.Cidade = cidade;
            this.Cep = cep;
            this.Taxa = taxa;

        }
        private int cliente_cod;
        public int Codigo
        {
            get {return this.cliente_cod;}
            set{this.cliente_cod = value;}
        }
        private string cliente_nome;
        public string Nome
        {
            get { return this.cliente_nome; }
            set { this.cliente_nome = value; }
        }
        private string cliente_email;
        public string Email
        {
            get { return this.cliente_email; }
            set { this.cliente_email = value; }
        }
        private string cliente_cel;
        public string Cel
        {
            get { return this.cliente_cel; }
            set { this.cliente_cel = value; }
        }
        private string cliente_rua;
        public string Rua
        {
            get { return this.cliente_rua; }
            set { this.cliente_rua = value; }
        }
        private string cliente_bairro;
        public string Bairro
        {
            get { return this.cliente_bairro; }
            set { this.cliente_bairro = value; }
        }
        private string cliente_cidade;
        public string Cidade
        {
            get { return this.cliente_cidade; }
            set { this.cliente_cidade = value; }
        }
        private string cliente_cep;
        public string Cep
        {
            get { return this.cliente_cep; }
            set { this.cliente_cep = value; }
        }
        private string cliente_taxa;
        public string Taxa
        {
            get { return this.cliente_taxa; }
            set { this.cliente_taxa = value; }
        }
    }
}
