﻿namespace Gestor
{
    partial class frmCadastroClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pDados = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.text_codigo = new System.Windows.Forms.TextBox();
            this.text_taxa = new System.Windows.Forms.TextBox();
            this.text_cep = new System.Windows.Forms.TextBox();
            this.text_cidade = new System.Windows.Forms.TextBox();
            this.text_bairro = new System.Windows.Forms.TextBox();
            this.text_rua = new System.Windows.Forms.TextBox();
            this.text_celular = new System.Windows.Forms.TextBox();
            this.text_email = new System.Windows.Forms.TextBox();
            this.text_nome = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pMenu = new System.Windows.Forms.Panel();
            this.bt_cancelar = new System.Windows.Forms.Button();
            this.bt_salvar = new System.Windows.Forms.Button();
            this.bt_excluir = new System.Windows.Forms.Button();
            this.bt_alterar = new System.Windows.Forms.Button();
            this.bt_localizar = new System.Windows.Forms.Button();
            this.bt_inserir = new System.Windows.Forms.Button();
            this.pDados.SuspendLayout();
            this.pMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pDados
            // 
            this.pDados.Controls.Add(this.label9);
            this.pDados.Controls.Add(this.text_codigo);
            this.pDados.Controls.Add(this.text_taxa);
            this.pDados.Controls.Add(this.text_cep);
            this.pDados.Controls.Add(this.text_cidade);
            this.pDados.Controls.Add(this.text_bairro);
            this.pDados.Controls.Add(this.text_rua);
            this.pDados.Controls.Add(this.text_celular);
            this.pDados.Controls.Add(this.text_email);
            this.pDados.Controls.Add(this.text_nome);
            this.pDados.Controls.Add(this.label8);
            this.pDados.Controls.Add(this.label7);
            this.pDados.Controls.Add(this.label6);
            this.pDados.Controls.Add(this.label5);
            this.pDados.Controls.Add(this.label4);
            this.pDados.Controls.Add(this.label3);
            this.pDados.Controls.Add(this.label2);
            this.pDados.Controls.Add(this.label1);
            this.pDados.Location = new System.Drawing.Point(9, 11);
            this.pDados.Margin = new System.Windows.Forms.Padding(4);
            this.pDados.Name = "pDados";
            this.pDados.Size = new System.Drawing.Size(896, 352);
            this.pDados.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 27);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 17);
            this.label9.TabIndex = 17;
            this.label9.Text = "Código";
            // 
            // text_codigo
            // 
            this.text_codigo.Enabled = false;
            this.text_codigo.Location = new System.Drawing.Point(71, 18);
            this.text_codigo.Margin = new System.Windows.Forms.Padding(4);
            this.text_codigo.Name = "text_codigo";
            this.text_codigo.Size = new System.Drawing.Size(117, 22);
            this.text_codigo.TabIndex = 16;
            // 
            // text_taxa
            // 
            this.text_taxa.Location = new System.Drawing.Point(71, 251);
            this.text_taxa.Margin = new System.Windows.Forms.Padding(4);
            this.text_taxa.Name = "text_taxa";
            this.text_taxa.Size = new System.Drawing.Size(240, 22);
            this.text_taxa.TabIndex = 15;
            // 
            // text_cep
            // 
            this.text_cep.Location = new System.Drawing.Point(71, 219);
            this.text_cep.Margin = new System.Windows.Forms.Padding(4);
            this.text_cep.Name = "text_cep";
            this.text_cep.Size = new System.Drawing.Size(240, 22);
            this.text_cep.TabIndex = 14;
            // 
            // text_cidade
            // 
            this.text_cidade.Location = new System.Drawing.Point(71, 187);
            this.text_cidade.Margin = new System.Windows.Forms.Padding(4);
            this.text_cidade.Name = "text_cidade";
            this.text_cidade.Size = new System.Drawing.Size(399, 22);
            this.text_cidade.TabIndex = 13;
            // 
            // text_bairro
            // 
            this.text_bairro.Location = new System.Drawing.Point(71, 155);
            this.text_bairro.Margin = new System.Windows.Forms.Padding(4);
            this.text_bairro.Name = "text_bairro";
            this.text_bairro.Size = new System.Drawing.Size(399, 22);
            this.text_bairro.TabIndex = 12;
            // 
            // text_rua
            // 
            this.text_rua.Location = new System.Drawing.Point(71, 123);
            this.text_rua.Margin = new System.Windows.Forms.Padding(4);
            this.text_rua.Name = "text_rua";
            this.text_rua.Size = new System.Drawing.Size(399, 22);
            this.text_rua.TabIndex = 11;
            // 
            // text_celular
            // 
            this.text_celular.Location = new System.Drawing.Point(71, 89);
            this.text_celular.Margin = new System.Windows.Forms.Padding(4);
            this.text_celular.Name = "text_celular";
            this.text_celular.Size = new System.Drawing.Size(240, 22);
            this.text_celular.TabIndex = 10;
            // 
            // text_email
            // 
            this.text_email.Location = new System.Drawing.Point(71, 286);
            this.text_email.Margin = new System.Windows.Forms.Padding(4);
            this.text_email.Name = "text_email";
            this.text_email.Size = new System.Drawing.Size(796, 22);
            this.text_email.TabIndex = 9;
            // 
            // text_nome
            // 
            this.text_nome.Location = new System.Drawing.Point(71, 50);
            this.text_nome.Margin = new System.Windows.Forms.Padding(4);
            this.text_nome.Name = "text_nome";
            this.text_nome.Size = new System.Drawing.Size(796, 22);
            this.text_nome.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 260);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "Taxa";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 228);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "CEP";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 196);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Cidade";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 164);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Bairro";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 132);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Rua";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 97);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Celular";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 294);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "e-mail";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 59);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // pMenu
            // 
            this.pMenu.Controls.Add(this.bt_cancelar);
            this.pMenu.Controls.Add(this.bt_salvar);
            this.pMenu.Controls.Add(this.bt_excluir);
            this.pMenu.Controls.Add(this.bt_alterar);
            this.pMenu.Controls.Add(this.bt_localizar);
            this.pMenu.Controls.Add(this.bt_inserir);
            this.pMenu.Location = new System.Drawing.Point(9, 370);
            this.pMenu.Margin = new System.Windows.Forms.Padding(4);
            this.pMenu.Name = "pMenu";
            this.pMenu.Size = new System.Drawing.Size(896, 62);
            this.pMenu.TabIndex = 1;
            // 
            // bt_cancelar
            // 
            this.bt_cancelar.Location = new System.Drawing.Point(760, 17);
            this.bt_cancelar.Margin = new System.Windows.Forms.Padding(4);
            this.bt_cancelar.Name = "bt_cancelar";
            this.bt_cancelar.Size = new System.Drawing.Size(100, 28);
            this.bt_cancelar.TabIndex = 5;
            this.bt_cancelar.Text = "Cancelar";
            this.bt_cancelar.UseVisualStyleBackColor = true;
            this.bt_cancelar.Click += new System.EventHandler(this.bt_cancelar_Click);
            // 
            // bt_salvar
            // 
            this.bt_salvar.Location = new System.Drawing.Point(609, 17);
            this.bt_salvar.Margin = new System.Windows.Forms.Padding(4);
            this.bt_salvar.Name = "bt_salvar";
            this.bt_salvar.Size = new System.Drawing.Size(100, 28);
            this.bt_salvar.TabIndex = 4;
            this.bt_salvar.Text = "Salvar";
            this.bt_salvar.UseVisualStyleBackColor = true;
            this.bt_salvar.Click += new System.EventHandler(this.bt_salvar_Click);
            // 
            // bt_excluir
            // 
            this.bt_excluir.Location = new System.Drawing.Point(465, 17);
            this.bt_excluir.Margin = new System.Windows.Forms.Padding(4);
            this.bt_excluir.Name = "bt_excluir";
            this.bt_excluir.Size = new System.Drawing.Size(100, 28);
            this.bt_excluir.TabIndex = 3;
            this.bt_excluir.Text = "Excluir";
            this.bt_excluir.UseVisualStyleBackColor = true;
            // 
            // bt_alterar
            // 
            this.bt_alterar.Location = new System.Drawing.Point(317, 17);
            this.bt_alterar.Margin = new System.Windows.Forms.Padding(4);
            this.bt_alterar.Name = "bt_alterar";
            this.bt_alterar.Size = new System.Drawing.Size(100, 28);
            this.bt_alterar.TabIndex = 2;
            this.bt_alterar.Text = "Alterar";
            this.bt_alterar.UseVisualStyleBackColor = true;
            this.bt_alterar.Click += new System.EventHandler(this.bt_alterar_Click);
            // 
            // bt_localizar
            // 
            this.bt_localizar.Location = new System.Drawing.Point(168, 17);
            this.bt_localizar.Margin = new System.Windows.Forms.Padding(4);
            this.bt_localizar.Name = "bt_localizar";
            this.bt_localizar.Size = new System.Drawing.Size(100, 28);
            this.bt_localizar.TabIndex = 1;
            this.bt_localizar.Text = "Localizar";
            this.bt_localizar.UseVisualStyleBackColor = true;
            this.bt_localizar.Click += new System.EventHandler(this.bt_localizar_Click);
            // 
            // bt_inserir
            // 
            this.bt_inserir.Location = new System.Drawing.Point(20, 17);
            this.bt_inserir.Margin = new System.Windows.Forms.Padding(4);
            this.bt_inserir.Name = "bt_inserir";
            this.bt_inserir.Size = new System.Drawing.Size(100, 28);
            this.bt_inserir.TabIndex = 0;
            this.bt_inserir.Text = "Inserir";
            this.bt_inserir.UseVisualStyleBackColor = true;
            this.bt_inserir.Click += new System.EventHandler(this.bt_inserir_Click);
            // 
            // frmCadastroClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 567);
            this.Controls.Add(this.pMenu);
            this.Controls.Add(this.pDados);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmCadastroClientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Clientes - Gestor de Pedidos ";
            this.Load += new System.EventHandler(this.frmCadastroClientes_Load);
            this.pDados.ResumeLayout(false);
            this.pDados.PerformLayout();
            this.pMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pDados;
        private System.Windows.Forms.Panel pMenu;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_cancelar;
        private System.Windows.Forms.Button bt_salvar;
        private System.Windows.Forms.Button bt_excluir;
        private System.Windows.Forms.Button bt_alterar;
        private System.Windows.Forms.Button bt_localizar;
        private System.Windows.Forms.Button bt_inserir;
        private System.Windows.Forms.TextBox text_taxa;
        private System.Windows.Forms.TextBox text_cep;
        private System.Windows.Forms.TextBox text_cidade;
        private System.Windows.Forms.TextBox text_bairro;
        private System.Windows.Forms.TextBox text_rua;
        private System.Windows.Forms.TextBox text_celular;
        private System.Windows.Forms.TextBox text_email;
        private System.Windows.Forms.TextBox text_nome;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox text_codigo;
    }
}