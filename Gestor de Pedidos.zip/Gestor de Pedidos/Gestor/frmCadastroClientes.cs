﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestor
{
    public partial class frmCadastroClientes : Form
    {
        public string operacao = ""; //propriedade operacao
        public frmCadastroClientes()
        {
            InitializeComponent();
        }
        public void AlteraBotoes(int op)
        {
            pDados.Enabled = false;
            bt_inserir.Enabled = false;
            bt_localizar.Enabled = false;
            bt_alterar.Enabled = false;
            bt_excluir.Enabled = false;
            bt_salvar.Enabled = false;
            bt_cancelar.Enabled = false;
            if (op == 01)
            {
                bt_inserir.Enabled = true;
                bt_localizar.Enabled = true;
            }
            if (op == 02)
            {
                pDados.Enabled = true;
                bt_salvar.Enabled = true;
                bt_cancelar.Enabled = true;
            }
            if (op == 03)
            {
                bt_excluir.Enabled = true;
                bt_alterar.Enabled = true;
            }
        }
        public void LimpaCampos()
        {
            text_codigo.Clear();
            text_nome.Clear();
            text_celular.Clear();
            text_rua.Clear();
            text_bairro.Clear();
            text_cidade.Clear();
            text_cep.Clear();
            text_taxa.Clear();
            text_email.Clear();
        }

        private void frmCadastroClientes_Load(object sender, EventArgs e)
        {
            this.AlteraBotoes(1);
        }

        private void bt_inserir_Click(object sender, EventArgs e)
        {
            this.operacao = "Inserir";
            this.AlteraBotoes(2);
        }

        private void bt_cancelar_Click(object sender, EventArgs e)
        {
         this.AlteraBotoes(1);//desabilita o painel de entrada de dados e botões
            this.LimpaCampos();//limpar os campos

        }

        private void bt_salvar_Click(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            cliente.Nome = text_nome.Text;
            cliente.Cel = text_celular.Text;
            cliente.Rua = text_rua.Text;
            cliente.Bairro = text_bairro.Text;
            cliente.Cidade = text_cidade.Text;
            cliente.Cep = text_cep.Text;
            cliente.Taxa = text_taxa.Text;
            cliente.Email = text_email.Text;
            string strConexao = "Data Source=NTBK-ALEX-SANTO\\SQLEXPRESS;Integrated Security=True";
            Conexao conexao = new Conexao(strConexao);
            DALCliente dal = new DALCliente(conexao);
            if (this.operacao == "Inserir")
            {
                dal.Incluir(cliente);
                MessageBox.Show("Cliente cadastrado com sucesso." +"Código do Cliente: "+ cliente.Codigo.ToString());
             }
            else
            {
                cliente.Codigo = Convert.ToInt32(text_codigo.Text);
                dal.Alterar(cliente);
                //alterar o cliente que esta na tela
            }
        }

        private void bt_alterar_Click(object sender, EventArgs e)
        {

        }

        private void bt_localizar_Click(object sender, EventArgs e)
        {

        }
    }
}
